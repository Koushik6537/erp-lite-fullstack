import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth/auth.service';

export const authGuard: CanActivateFn = (route) => {

  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/login']);
    return false;
  }

  // Role-based check
  const expectedRole = route.data?.['role'];

  if (expectedRole && authService.getRole() !== expectedRole) {
    alert('Access denied');
    router.navigate(['/dashboard']);
    return false;
  }

  return true;

  // console.log('Expected Role:', expectedRole);
  // console.log('User Role:', authService.getRole());
};