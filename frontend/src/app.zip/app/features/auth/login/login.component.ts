import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth/auth.service';
import { jwtDecode } from 'jwt-decode';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  loginForm: FormGroup;

  constructor(private fb: FormBuilder, private router: Router, private authService: AuthService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {

      const { email, password } = this.loginForm.value;

      this.authService.login(email, password).subscribe({
        next: (res: any) => {

          // ✅ Save token
          localStorage.setItem('token', res);

          // ✅ Decode token
          const decoded: any = jwtDecode(res);

          // ✅ Save user
          localStorage.setItem('user', JSON.stringify({
            email: decoded.sub,
            role: decoded.role
          }));

          // ✅ Navigate
          this.router.navigate(['/dashboard']);
        },

        error: () => {
          alert('Invalid credentials');
        }
      });
    }
  }
}