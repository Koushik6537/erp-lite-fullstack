import { Component } from '@angular/core';
import { ApiService } from '../../../core/services/api/api.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  imports: [FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user = {
    name: '',
    email: '',
    password: '',
    role: ''
  };

  constructor(private api: ApiService) {}

  register() {
    this.api.register(this.user).subscribe({
      next: () => {
        alert('Registration successful');
      },
      error: () => {
        alert('User already exists');
      }
    });
  }
}
