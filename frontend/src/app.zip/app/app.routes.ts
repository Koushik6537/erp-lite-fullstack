import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';


export const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./layout/layout/layout.component').then(m => m.LayoutComponent),
      canActivate: [authGuard],
      children: [
        {
          path: '',
          redirectTo: 'login',
          pathMatch: 'full'
        },
        { 
          path: 'register',
          loadComponent: () =>
            import('./features/auth/register/register.component')
              .then(m => m.RegisterComponent)
        },
        {
          path: 'dashboard',
          loadComponent: () =>
            import('./features/dashboard/dashboard.component')
              .then(m => m.DashboardComponent)
        },
        {
          path: 'employees',
          loadComponent: () =>
          import('./features/employee/employee.component')
          .then(m => m.EmployeeComponent),
          canActivate: [authGuard],
          data: { role: 'Admin' } // employees tab is only accessible to admin
        },
        {
          path: 'tasks',
          loadComponent: () =>
          import('./features/task/task.component')
          .then(m => m.TaskComponent),
          canActivate: [authGuard]
        },
        {
          path: 'leave',
          loadComponent: () =>
            import('./features/leave/leave.component')
              .then(m => m.LeaveComponent),
          canActivate: [authGuard]
        }
      ]
  },
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login/login.component')
        .then(m => m.LoginComponent)
  }
];